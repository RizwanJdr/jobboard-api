/**
 * Skills extraction and job matching utilities
 */

export const SKILL_TAXONOMY = {
  languages: [
    'javascript', 'typescript', 'python', 'java', 'go', 'golang', 'rust', 
    'c++', 'c#', 'ruby', 'php', 'swift', 'kotlin', 'scala', 'r', 'sql'
  ],
  frontend: [
    'react', 'vue', 'angular', 'svelte', 'nextjs', 'next.js', 'nuxt',
    'html', 'css', 'sass', 'tailwind', 'webpack', 'vite'
  ],
  backend: [
    'node', 'nodejs', 'express', 'django', 'flask', 'fastapi', 'rails',
    'spring', 'laravel', 'gin', 'fiber', 'actix'
  ],
  data: [
    'postgres', 'postgresql', 'mysql', 'mongodb', 'redis', 'elasticsearch',
    'kafka', 'spark', 'hadoop', 'snowflake', 'bigquery', 'pandas', 'numpy'
  ],
  cloud: [
    'aws', 'gcp', 'azure', 'heroku', 'vercel', 'netlify', 'cloudflare'
  ],
  devops: [
    'docker', 'kubernetes', 'k8s', 'terraform', 'ansible', 'jenkins',
    'github actions', 'gitlab ci', 'circleci', 'prometheus', 'grafana'
  ],
  ml: [
    'machine learning', 'deep learning', 'tensorflow', 'pytorch', 'scikit-learn',
    'nlp', 'computer vision', 'llm', 'transformers', 'huggingface'
  ]
};

const ALL_SKILLS = new Set(Object.values(SKILL_TAXONOMY).flat());

export function extractSkills(text, options = {}) {
  const normalized = text.toLowerCase();
  const found = [];

  for (const skill of ALL_SKILLS) {
    const pattern = new RegExp(`\\b${skill.replace(/[+.]/g, '\\$&')}\\b`, 'i');
    if (pattern.test(normalized)) {
      found.push(skill);
    }
  }

  if (options.categorize) {
    const categorized = {};
    for (const [category, skills] of Object.entries(SKILL_TAXONOMY)) {
      const matches = found.filter(s => skills.includes(s));
      if (matches.length) categorized[category] = matches;
    }
    return categorized;
  }

  return [...new Set(found)];
}

export function matchScore(candidateSkills, jobSkills, jobRequirements = []) {
  if (!jobSkills.length && !jobRequirements.length) {
    return { score: 0.5, matched: [], missing: [] };
  }

  const candidateSet = new Set(candidateSkills.map(s => s.toLowerCase()));
  const jobSet = new Set([
    ...jobSkills.map(s => s.toLowerCase()),
    ...extractSkills(jobRequirements.join(' '))
  ]);

  const matched = [];
  const missing = [];

  for (const skill of jobSet) {
    if (candidateSet.has(skill)) {
      matched.push(skill);
    } else {
      missing.push(skill);
    }
  }

  const score = jobSet.size > 0 ? matched.length / jobSet.size : 0;

  return { score, matched, missing };
}

export function estimateExperienceLevel(text) {
  const lower = text.toLowerCase();
  
  const yearsMatch = lower.match(/(\d+)\+?\s*(?:years?|yrs?)/);
  if (yearsMatch) {
    const years = parseInt(yearsMatch[1]);
    if (years >= 10) return 'executive';
    if (years >= 7) return 'lead';
    if (years >= 4) return 'senior';
    if (years >= 2) return 'mid';
    return 'entry';
  }

  if (/\b(?:principal|staff|director|vp|head of)\b/i.test(lower)) return 'executive';
  if (/\b(?:lead|tech lead|team lead|architect)\b/i.test(lower)) return 'lead';
  if (/\b(?:senior|sr\.?|experienced)\b/i.test(lower)) return 'senior';
  if (/\b(?:junior|jr\.?|entry|graduate|intern)\b/i.test(lower)) return 'entry';
  
  return 'mid';
}

export function parseSalary(text) {
  const patterns = [
    /\$(\d{2,3})[,.]?(\d{3})?\s*[-–to]+\s*\$?(\d{2,3})[,.]?(\d{3})?/i,
    /(\d{2,3})k?\s*[-–to]+\s*(\d{2,3})k/i,
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      let min, max;
      
      if (match[2]) {
        min = parseInt(match[1] + (match[2] || '000'));
        max = parseInt(match[3] + (match[4] || '000'));
      } else {
        min = parseInt(match[1]) * 1000;
        max = parseInt(match[2] || match[3]) * 1000;
      }

      if (min > 0 && min < 1000000 && max > min) {
        return { min, max, currency: 'USD', period: 'year' };
      }
    }
  }

  return null;
}

export default { SKILL_TAXONOMY, extractSkills, matchScore, estimateExperienceLevel, parseSalary };
