/**
 * JobBoard SDK - Core types and interfaces
 */

// Standardized job posting schema
export class Job {
  constructor(data) {
    this.id = data.id || crypto.randomUUID();
    this.title = data.title;
    this.company = data.company;
    this.location = data.location || null;
    this.remote = data.remote || false;
    this.remoteType = data.remoteType || null;
    this.salaryMin = data.salaryMin || null;
    this.salaryMax = data.salaryMax || null;
    this.salaryCurrency = data.salaryCurrency || 'USD';
    this.salaryPeriod = data.salaryPeriod || 'year';
    this.description = data.description || '';
    this.requirements = data.requirements || [];
    this.skills = data.skills || [];
    this.experienceLevel = data.experienceLevel || null;
    this.employmentType = data.employmentType || 'full-time';
    this.postedAt = data.postedAt ? new Date(data.postedAt) : new Date();
    this.expiresAt = data.expiresAt ? new Date(data.expiresAt) : null;
    this.applyUrl = data.applyUrl || null;
    this.source = data.source || 'unknown';
    this.sourceId = data.sourceId || null;
    this.raw = data.raw || null;
  }

  matches(filters) {
    if (filters.query) {
      const q = filters.query.toLowerCase();
      const searchable = `${this.title} ${this.company} ${this.description} ${this.skills.join(' ')}`.toLowerCase();
      if (!searchable.includes(q)) return false;
    }
    if (filters.remote === true && !this.remote) return false;
    if (filters.location && this.location && !this.location.toLowerCase().includes(filters.location.toLowerCase())) return false;
    if (filters.minSalary && this.salaryMin && this.salaryMin < filters.minSalary) return false;
    if (filters.experienceLevel && this.experienceLevel !== filters.experienceLevel) return false;
    if (filters.skills?.length) {
      const jobSkills = this.skills.map(s => s.toLowerCase());
      if (!filters.skills.some(s => jobSkills.includes(s.toLowerCase()))) return false;
    }
    return true;
  }

  toJSON() {
    return {
      id: this.id,
      title: this.title,
      company: this.company,
      location: this.location,
      remote: this.remote,
      remoteType: this.remoteType,
      salaryMin: this.salaryMin,
      salaryMax: this.salaryMax,
      salaryCurrency: this.salaryCurrency,
      salaryPeriod: this.salaryPeriod,
      description: this.description,
      requirements: this.requirements,
      skills: this.skills,
      experienceLevel: this.experienceLevel,
      employmentType: this.employmentType,
      postedAt: this.postedAt.toISOString(),
      expiresAt: this.expiresAt?.toISOString() || null,
      applyUrl: this.applyUrl,
      source: this.source,
      sourceId: this.sourceId
    };
  }
}

// Base adapter interface
export class JobAdapter {
  constructor(name, config = {}) {
    this.name = name;
    this.config = config;
  }

  async fetchJobs(options = {}) {
    throw new Error('fetchJobs not implemented');
  }

  normalize(rawData) {
    throw new Error('normalize not implemented');
  }
}

// Job aggregator - combines multiple adapters
export class JobAggregator {
  constructor() {
    this.adapters = new Map();
  }

  registerAdapter(adapter) {
    this.adapters.set(adapter.name, adapter);
    return this;
  }

  async fetchAll(options = {}) {
    const results = await Promise.allSettled(
      Array.from(this.adapters.values()).map(adapter => 
        adapter.fetchJobs(options)
      )
    );

    const jobs = [];
    const errors = [];

    results.forEach((result, i) => {
      if (result.status === 'fulfilled') {
        jobs.push(...result.value);
      } else {
        errors.push({
          adapter: Array.from(this.adapters.keys())[i],
          error: result.reason.message
        });
      }
    });

    return { jobs: this.deduplicate(jobs), errors };
  }

  async search(filters = {}) {
    const { jobs, errors } = await this.fetchAll(filters);
    return {
      jobs: jobs.filter(job => job.matches(filters)),
      errors
    };
  }

  deduplicate(jobs) {
    const seen = new Map();
    const unique = [];

    for (const job of jobs) {
      const key = this.normalizeKey(job);
      if (!seen.has(key)) {
        seen.set(key, true);
        unique.push(job);
      }
    }

    return unique;
  }

  normalizeKey(job) {
    const title = job.title.toLowerCase().replace(/[^a-z0-9]/g, '');
    const company = job.company.toLowerCase().replace(/[^a-z0-9]/g, '');
    return `${title}:${company}`;
  }
}

export default { Job, JobAdapter, JobAggregator };
