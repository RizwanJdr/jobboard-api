/**
 * Hacker News Who's Hiring Adapter
 * Fetches from monthly "Ask HN: Who is Hiring?" threads
 */

import { JobAdapter, Job } from '../index.js';

export class HNHiringAdapter extends JobAdapter {
  constructor(config = {}) {
    super('hn-hiring', config);
    this.baseUrl = 'https://hacker-news.firebaseio.com/v0';
  }

  async fetchJobs(options = {}) {
    const threadId = options.threadId || await this.findLatestThread();
    if (!threadId) {
      throw new Error('Could not find Who is Hiring thread');
    }

    const thread = await this.fetchItem(threadId);
    if (!thread.kids?.length) return [];

    const limit = options.limit || 100;
    const commentIds = thread.kids.slice(0, limit);
    
    const comments = await Promise.all(
      commentIds.map(id => this.fetchItem(id))
    );

    return comments
      .filter(c => c && c.text && !c.deleted && !c.dead)
      .map(c => this.normalize(c));
  }

  async fetchItem(id) {
    const response = await fetch(`${this.baseUrl}/item/${id}.json`);
    return response.json();
  }

  async findLatestThread() {
    const response = await fetch(
      'https://hn.algolia.com/api/v1/search_by_date?' + 
      new URLSearchParams({
        query: '"Ask HN: Who is hiring"',
        tags: 'story',
        numericFilters: 'points>100'
      })
    );
    
    const data = await response.json();
    if (data.hits?.length) {
      return parseInt(data.hits[0].objectID);
    }
    return null;
  }

  normalize(comment) {
    const text = comment.text || '';
    const parsed = this.parsePosting(text);

    return new Job({
      title: parsed.title || 'Software Engineer',
      company: parsed.company || 'Unknown',
      location: parsed.location,
      remote: parsed.remote,
      remoteType: parsed.remoteType,
      description: this.stripHtml(text),
      skills: parsed.skills,
      experienceLevel: parsed.experienceLevel,
      employmentType: 'full-time',
      postedAt: new Date(comment.time * 1000),
      applyUrl: parsed.applyUrl || `https://news.ycombinator.com/item?id=${comment.id}`,
      source: 'hn-hiring',
      sourceId: comment.id?.toString(),
      raw: comment
    });
  }

  parsePosting(text) {
    const result = {
      company: null,
      title: null,
      location: null,
      remote: false,
      remoteType: null,
      skills: [],
      experienceLevel: null,
      applyUrl: null
    };

    const clean = this.stripHtml(text);
    const firstLine = clean.split('\n')[0];
    const parts = firstLine.split('|').map(p => p.trim());

    if (parts.length >= 1) result.company = parts[0];
    
    const remoteIdx = parts.findIndex(p => /remote/i.test(p));
    if (remoteIdx !== -1) {
      result.remote = true;
      if (/hybrid/i.test(parts[remoteIdx])) result.remoteType = 'hybrid';
      else result.remoteType = 'full';
    }

    for (const part of parts) {
      if (/(?:SF|NYC|LA|Seattle|London|Berlin|Toronto|Austin|Boston|Remote)/i.test(part)) {
        if (!/remote/i.test(part)) {
          result.location = part;
        }
      }
    }

    for (const part of parts) {
      if (/(?:engineer|developer|designer|manager|lead|architect)/i.test(part)) {
        result.title = part;
        break;
      }
    }

    const techPatterns = /\b(python|javascript|typescript|react|node|go|rust|java|c\+\+|ruby|rails|django|vue|angular|kubernetes|aws|gcp|azure|docker|postgres|mysql|redis|graphql)\b/gi;
    const matches = clean.match(techPatterns) || [];
    result.skills = [...new Set(matches.map(m => m.toLowerCase()))];

    if (/senior|sr\./i.test(clean)) result.experienceLevel = 'senior';
    else if (/junior|jr\./i.test(clean)) result.experienceLevel = 'entry';
    else if (/lead/i.test(clean)) result.experienceLevel = 'lead';

    const urlMatch = clean.match(/https?:\/\/[^\s<>"]+/);
    if (urlMatch) result.applyUrl = urlMatch[0];

    return result;
  }

  stripHtml(html) {
    return html
      .replace(/<[^>]+>/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#x27;/g, "'")
      .replace(/&#x2F;/g, '/')
      .replace(/\s+/g, ' ')
      .trim();
  }
}

export default HNHiringAdapter;
