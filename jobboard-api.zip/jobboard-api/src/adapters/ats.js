/**
 * Greenhouse & Lever Adapters - Company job boards
 */

import { JobAdapter, Job } from '../index.js';

export class GreenhouseAdapter extends JobAdapter {
  constructor(config = {}) {
    super('greenhouse', config);
    this.boardToken = config.boardToken;
  }

  async fetchJobs(options = {}) {
    if (!this.boardToken) {
      throw new Error('Greenhouse adapter requires boardToken config');
    }

    const url = `https://boards-api.greenhouse.io/v1/boards/${this.boardToken}/jobs`;
    
    const response = await fetch(url, {
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      throw new Error(`Greenhouse API error: ${response.status}`);
    }

    const data = await response.json();
    
    const jobs = await Promise.all(
      data.jobs.map(async (job) => {
        const details = await this.fetchJobDetails(job.id);
        return this.normalize({ ...job, ...details });
      })
    );

    return jobs;
  }

  async fetchJobDetails(jobId) {
    const url = `https://boards-api.greenhouse.io/v1/boards/${this.boardToken}/jobs/${jobId}`;
    const response = await fetch(url);
    if (!response.ok) return {};
    return response.json();
  }

  normalize(raw) {
    const location = raw.location?.name || null;
    const remote = /remote/i.test(location || '');

    const skills = [];
    if (raw.departments?.length) {
      raw.departments.forEach(d => skills.push(d.name));
    }

    return new Job({
      title: raw.title,
      company: this.boardToken,
      location: location,
      remote,
      remoteType: remote ? 'full' : null,
      description: this.stripHtml(raw.content || ''),
      skills,
      employmentType: 'full-time',
      postedAt: raw.updated_at ? new Date(raw.updated_at) : new Date(),
      applyUrl: raw.absolute_url,
      source: 'greenhouse',
      sourceId: raw.id?.toString(),
      raw
    });
  }

  stripHtml(html) {
    return html
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }
}


export class LeverAdapter extends JobAdapter {
  constructor(config = {}) {
    super('lever', config);
    this.companySlug = config.companySlug;
  }

  async fetchJobs(options = {}) {
    if (!this.companySlug) {
      throw new Error('Lever adapter requires companySlug config');
    }

    const url = `https://api.lever.co/v0/postings/${this.companySlug}`;
    
    const response = await fetch(url, {
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      throw new Error(`Lever API error: ${response.status}`);
    }

    const data = await response.json();
    return data.map(job => this.normalize(job));
  }

  normalize(raw) {
    const location = raw.categories?.location || null;
    const remote = /remote/i.test(location || '');

    const skills = [];
    if (raw.categories?.team) skills.push(raw.categories.team);
    if (raw.categories?.department) skills.push(raw.categories.department);

    let employmentType = 'full-time';
    const commitment = raw.categories?.commitment?.toLowerCase() || '';
    if (commitment.includes('part')) employmentType = 'part-time';
    else if (commitment.includes('contract')) employmentType = 'contract';
    else if (commitment.includes('intern')) employmentType = 'internship';

    return new Job({
      title: raw.text,
      company: this.companySlug,
      location,
      remote,
      remoteType: remote ? 'full' : null,
      description: raw.descriptionPlain || raw.description || '',
      skills,
      employmentType,
      postedAt: raw.createdAt ? new Date(raw.createdAt) : new Date(),
      applyUrl: raw.hostedUrl,
      source: 'lever',
      sourceId: raw.id,
      raw
    });
  }
}

export default { GreenhouseAdapter, LeverAdapter };
