/**
 * RemoteOK Adapter - Free public API
 * API docs: https://remoteok.com/api
 */

import { JobAdapter, Job } from '../index.js';

export class RemoteOKAdapter extends JobAdapter {
  constructor(config = {}) {
    super('remoteok', config);
    this.baseUrl = 'https://remoteok.com/api';
  }

  async fetchJobs(options = {}) {
    const response = await fetch(this.baseUrl, {
      headers: {
        'User-Agent': 'JobBoardAPI/1.0 (https://github.com/your-username/jobboard-api)'
      }
    });

    if (!response.ok) {
      throw new Error(`RemoteOK API error: ${response.status}`);
    }

    const data = await response.json();
    
    // First item is metadata, rest are jobs
    const jobs = data.slice(1).map(item => this.normalize(item));
    
    return jobs;
  }

  normalize(raw) {
    let salaryMin = null;
    let salaryMax = null;
    
    if (raw.salary_min) salaryMin = parseInt(raw.salary_min);
    if (raw.salary_max) salaryMax = parseInt(raw.salary_max);

    let experienceLevel = null;
    const tags = raw.tags || [];
    if (tags.includes('senior')) experienceLevel = 'senior';
    else if (tags.includes('junior') || tags.includes('entry')) experienceLevel = 'entry';
    else if (tags.includes('lead')) experienceLevel = 'lead';

    return new Job({
      title: raw.position,
      company: raw.company,
      location: raw.location || 'Remote',
      remote: true,
      remoteType: 'full',
      salaryMin,
      salaryMax,
      salaryCurrency: 'USD',
      salaryPeriod: 'year',
      description: raw.description || '',
      skills: tags.filter(t => !['senior', 'junior', 'entry', 'lead', 'remote'].includes(t)),
      experienceLevel,
      employmentType: 'full-time',
      postedAt: raw.date ? new Date(raw.date) : new Date(),
      applyUrl: raw.url,
      source: 'remoteok',
      sourceId: raw.id?.toString(),
      raw
    });
  }
}

export default RemoteOKAdapter;
