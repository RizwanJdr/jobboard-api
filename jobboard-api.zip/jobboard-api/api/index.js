/**
 * GET /api
 * Health check and API info
 */

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');

  return res.status(200).json({
    name: 'JobBoard API',
    version: '1.0.0',
    status: 'healthy',
    endpoints: {
      jobs: {
        url: '/api/jobs',
        method: 'GET',
        params: {
          q: 'Search query (searches title, company, description, skills)',
          remote: 'Filter remote jobs (true/false)',
          location: 'Filter by location',
          minSalary: 'Minimum salary filter',
          skills: 'Comma-separated skills to filter',
          source: 'Filter by source (remoteok, hn-hiring)',
          limit: 'Max results (default: 100)'
        },
        example: '/api/jobs?q=react&remote=true&minSalary=100000'
      },
      skills: {
        url: '/api/skills',
        method: 'GET',
        params: {
          text: 'Text to extract skills from',
          categorize: 'Group skills by category (true/false)',
          candidate: 'Candidate skills for matching',
          job: 'Job skills for matching'
        },
        examples: {
          extract: '/api/skills?text=Looking for React and Python developer',
          match: '/api/skills?candidate=react,python,aws&job=react,node,docker'
        }
      }
    },
    sources: [
      { name: 'RemoteOK', id: 'remoteok', auth: false },
      { name: 'HN Who\'s Hiring', id: 'hn-hiring', auth: false },
      { name: 'Greenhouse', id: 'greenhouse', auth: 'boardToken' },
      { name: 'Lever', id: 'lever', auth: 'companySlug' }
    ],
    github: 'https://github.com/YOUR_USERNAME/jobboard-api',
    license: 'MIT'
  });
}
