/**
 * GET /api/skills
 * Extract skills from text or match candidate skills to job
 * 
 * Query params:
 *  - text: text to extract skills from
 *  - categorize: true/false - group skills by category
 *  - candidate: comma-separated candidate skills (for matching)
 *  - job: comma-separated job skills (for matching)
 */

import { extractSkills, matchScore, estimateExperienceLevel, parseSalary, SKILL_TAXONOMY } from '../src/utils/skills.js';

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    const { text, categorize, candidate, job } = req.query;

    // Match mode
    if (candidate && job) {
      const candidateSkills = candidate.split(',').map(s => s.trim());
      const jobSkills = job.split(',').map(s => s.trim());
      
      const result = matchScore(candidateSkills, jobSkills);
      
      return res.status(200).json({
        success: true,
        mode: 'match',
        score: Math.round(result.score * 100),
        matched: result.matched,
        missing: result.missing
      });
    }

    // Extract mode
    if (text) {
      const skills = extractSkills(text, { categorize: categorize === 'true' });
      const experienceLevel = estimateExperienceLevel(text);
      const salary = parseSalary(text);

      return res.status(200).json({
        success: true,
        mode: 'extract',
        skills,
        experienceLevel,
        salary
      });
    }

    // Return taxonomy if no params
    return res.status(200).json({
      success: true,
      mode: 'taxonomy',
      taxonomy: SKILL_TAXONOMY,
      usage: {
        extract: '/api/skills?text=Looking for React and Python developer',
        categorize: '/api/skills?text=...&categorize=true',
        match: '/api/skills?candidate=react,python&job=react,node,aws'
      }
    });

  } catch (error) {
    console.error('Skills API Error:', error);
    return res.status(500).json({
      success: false,
      error: error.message
    });
  }
}
