/**
 * GET /api/jobs
 * Fetch all jobs from all sources
 * 
 * Query params:
 *  - q: search query
 *  - remote: true/false
 *  - location: location filter
 *  - minSalary: minimum salary
 *  - skills: comma-separated skills
 *  - source: filter by source (remoteok, hn-hiring, greenhouse, lever)
 */

import { JobAggregator } from '../src/index.js';
import RemoteOKAdapter from '../src/adapters/remoteok.js';
import HNHiringAdapter from '../src/adapters/hn-hiring.js';
import { GreenhouseAdapter, LeverAdapter } from '../src/adapters/ats.js';

// Cache jobs for 5 minutes to avoid rate limits
let cache = { jobs: null, timestamp: 0, errors: [] };
const CACHE_TTL = 5 * 60 * 1000;

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { q, remote, location, minSalary, skills, source, limit } = req.query;

    // Check cache
    const now = Date.now();
    if (!cache.jobs || now - cache.timestamp > CACHE_TTL) {
      const aggregator = new JobAggregator();
      
      // Register adapters
      aggregator.registerAdapter(new RemoteOKAdapter());
      aggregator.registerAdapter(new HNHiringAdapter());
      
      // Add company boards (examples - you can customize these)
      // aggregator.registerAdapter(new GreenhouseAdapter({ boardToken: 'stripe' }));
      // aggregator.registerAdapter(new LeverAdapter({ companySlug: 'figma' }));

      const { jobs, errors } = await aggregator.fetchAll({ limit: 200 });
      
      cache = {
        jobs: jobs.map(j => j.toJSON()),
        errors,
        timestamp: now
      };
    }

    // Apply filters
    let filteredJobs = [...cache.jobs];

    // Text search
    if (q) {
      const query = q.toLowerCase();
      filteredJobs = filteredJobs.filter(job => {
        const searchable = `${job.title} ${job.company} ${job.description} ${job.skills.join(' ')}`.toLowerCase();
        return searchable.includes(query);
      });
    }

    // Remote filter
    if (remote === 'true') {
      filteredJobs = filteredJobs.filter(job => job.remote === true);
    }

    // Location filter
    if (location) {
      const loc = location.toLowerCase();
      filteredJobs = filteredJobs.filter(job => 
        job.location?.toLowerCase().includes(loc)
      );
    }

    // Salary filter
    if (minSalary) {
      const min = parseInt(minSalary);
      filteredJobs = filteredJobs.filter(job => 
        job.salaryMin && job.salaryMin >= min
      );
    }

    // Skills filter
    if (skills) {
      const skillList = skills.split(',').map(s => s.trim().toLowerCase());
      filteredJobs = filteredJobs.filter(job => 
        job.skills.some(s => skillList.includes(s.toLowerCase()))
      );
    }

    // Source filter
    if (source) {
      filteredJobs = filteredJobs.filter(job => job.source === source);
    }

    // Limit results
    const resultLimit = parseInt(limit) || 100;
    filteredJobs = filteredJobs.slice(0, resultLimit);

    return res.status(200).json({
      success: true,
      count: filteredJobs.length,
      jobs: filteredJobs,
      errors: cache.errors,
      cached: now - cache.timestamp < CACHE_TTL,
      sources: ['remoteok', 'hn-hiring']
    });

  } catch (error) {
    console.error('API Error:', error);
    return res.status(500).json({
      success: false,
      error: error.message
    });
  }
}
